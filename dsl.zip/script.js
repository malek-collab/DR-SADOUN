// CANVAS PARTICULES
const canvas = document.getElementById('particles-canvas');
const ctx = canvas.getContext('2d');
let particles = [];

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

function initParticles() {
  particles = [];
  const particleCount = Math.min(80, Math.floor(window.innerWidth / 20));
  for (let i = 0; i < particleCount; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 3 + 1,
      alpha: Math.random() * 0.3 + 0.1,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.2
    });
  }
}

function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let p of particles) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(44, 98, 140, ${p.alpha})`;
    ctx.fill();
    p.x += p.vx;
    p.y += p.vy;
    if (p.x < 0) p.x = canvas.width;
    if (p.x > canvas.width) p.x = 0;
    if (p.y < 0) p.y = canvas.height;
    if (p.y > canvas.height) p.y = 0;
  }
  requestAnimationFrame(drawParticles);
}

window.addEventListener('resize', () => { resizeCanvas(); initParticles(); });
resizeCanvas();
initParticles();
drawParticles();

// TRADUCTIONS (FR, EN, AR)
const translations = {
  fr: {
    "dr-name": "Dr Sadoun",
    "dr-title": "Chirurgien-dentiste à Alger",
    "nav-home": "Accueil",
    "nav-services": "Soins",
    "nav-engagement": "Cabinet",
    "nav-testimonials": "Avis",
    "nav-rdv": "RDV",
    "nav-contact": "Contact",
    "hero-badge": "Soins modernes sans douleur",
    "hero-span1": "Votre",
    "hero-span2": "sourire",
    "hero-span3": "notre priorité",
    "hero-desc": "Dr Sadoun, chirurgien-dentiste à Alger (Ouled Fayet), vous accueille dans un cabinet moderne pour des soins de qualité, personnalisés et réalisés avec des technologies de pointe.",
    "speciality": "🦷 Chirurgie dentaire & Implantologie",
    "btn-rdv-hero": "Prendre rendez-vous",
    "services-title": "Soins dentaires complets",
    "services-sub": "Des prestations adaptées à chaque patient, de la prévention aux traitements complexes.",
    "service1-title": "Consultation et prévention",
    "service1-desc": "Bilan complet, détartrage, conseils personnalisés.",
    "service2-title": "Soins conservateurs",
    "service2-desc": "Traitement des caries, restauration des dents abîmées.",
    "service3-title": "Esthétique dentaire",
    "service3-desc": "Blanchiment, facettes, gouttières pour un sourire éclatant.",
    "service4-title": "Implantologie",
    "service4-desc": "Implants dentaires 3D, reconstruction osseuse.",
    "service5-title": "Pédodontie",
    "service5-desc": "Soins dentaires pour enfants, ambiance ludique et sans stress.",
    "service6-title": "Parodontie",
    "service6-desc": "Traitement des gencives, prévention des maladies parodontales.",
    "engagement-title": "Un cabinet moderne et bienveillant",
    "engagement-desc": "Dr Sadoun met un point d'honneur à offrir des soins indolores grâce à des techniques d'anesthésie avancées et à une écoute attentive. Il prend le temps d'expliquer chaque étape du traitement pour réduire l'anxiété de ses patients. Le cabinet est équipé des dernières technologies : laser, caméra intra-buccale, radiographie numérique.",
    "engagement-btn": "Prendre rendez-vous",
    "testimonials-title": "Ils parlent de nous",
    "testimonials-sub": "Ils ont confié leur sourire au Dr Sadoun et partagent leur expérience.",
    "testimonial1-text": "\"Dr Sadoun est très compétent et rassurant. Il m'a expliqué tout le processus de mon implant en détail. Je recommande vivement !\"",
    "testimonial1-name": "— Karim B.",
    "testimonial2-text": "\"Un cabinet moderne, une équipe aux petits soins. Je n'ai plus peur d'aller chez le dentiste grâce au Dr Sadoun. Les résultats sont parfaits.\"",
    "testimonial2-name": "— Samia M.",
    "testimonial3-text": "\"Très bon accueil, soins de qualité. Le Dr Sadoun prend le temps de répondre à toutes les questions. Je le recommande sans hésitation.\"",
    "testimonial3-name": "— Leila K.",
    "testimonial4-text": "\"Excellent chirurgien-dentiste, très doux. Mes enfants n'ont plus peur des soins dentaires. Merci docteur !\"",
    "testimonial4-name": "— Nadia F.",
    "rdv-title": "Prenez rendez-vous en ligne",
    "call-btn": "Appeler directement",
    "form-alt": "Ou remplissez le formulaire ci-dessous. Vous serez contacté(e) rapidement.",
    "form-name": "Nom complet",
    "form-email": "Votre email",
    "form-phone": "Téléphone",
    "form-message": "Message (optionnel)",
    "submit-btn": "Envoyer ma demande",
    "rdv-list-title": "Vos rendez-vous à venir (sauvegardés localement)",
    "service-opt1": "Consultation classique",
    "service-opt2": "Détartrage",
    "service-opt3": "Implantologie",
    "service-opt4": "Blanchiment",
    "service-opt5": "Parodontie",
    "contact-title": "Cabinet & coordonnées",
    "hours-title": "Horaires",
    "hours-desc": "Lun-Ven : 9h00 - 18h00<br>Samedi : 9h00 - 12h00<br>Dimanche : fermé",
    "address-title": "Adresse",
    "address-desc": "Ouled Fayet<br>Alger, 16000, Algérie",
    "contact-title2": "Contact",
    "cta-title": "Prêt à prendre soin de votre sourire ?",
    "cta-desc": "Contactez-nous dès maintenant pour fixer votre consultation.",
    "cta-btn": "Appeler pour rendez-vous",
    "footer-name": "Dr Sadoun",
    "footer-title": "Chirurgien-dentiste à Alger",
    "footer-clinic": "Cabinet dentaire moderne - Ouled Fayet",
    "footer-links": "Liens rapides",
    "footer-home": "Accueil",
    "footer-services": "Soins",
    "footer-rdv": "RDV",
    "footer-follow": "Suivez-nous"
  },
  en: {
    "dr-name": "Dr Sadoun",
    "dr-title": "Dental Surgeon in Algiers",
    "nav-home": "Home",
    "nav-services": "Treatments",
    "nav-engagement": "Practice",
    "nav-testimonials": "Reviews",
    "nav-rdv": "Appointment",
    "nav-contact": "Contact",
    "hero-badge": "Modern painless care",
    "hero-span1": "Your",
    "hero-span2": "smile",
    "hero-span3": "our priority",
    "hero-desc": "Dr Sadoun, dental surgeon in Algiers (Ouled Fayet), welcomes you to a modern practice for quality, personalized care using cutting-edge technology.",
    "speciality": "🦷 Oral Surgery & Implantology",
    "btn-rdv-hero": "Book appointment",
    "services-title": "Complete dental care",
    "services-sub": "Services tailored to each patient, from prevention to complex treatments.",
    "service1-title": "Consultation & Prevention",
    "service1-desc": "Full check-up, scaling, personalized advice.",
    "service2-title": "Restorative Dentistry",
    "service2-desc": "Caries treatment, restoration of damaged teeth.",
    "service3-title": "Aesthetic Dentistry",
    "service3-desc": "Whitening, veneers, aligners for a radiant smile.",
    "service4-title": "Implantology",
    "service4-desc": "3D dental implants, bone reconstruction.",
    "service5-title": "Pediatric Dentistry",
    "service5-desc": "Dental care for children, fun and stress-free atmosphere.",
    "service6-title": "Periodontics",
    "service6-desc": "Gum disease treatment, prevention of periodontal diseases.",
    "engagement-title": "A modern and caring practice",
    "engagement-desc": "Dr Sadoun is committed to providing painless care thanks to advanced anesthesia techniques and attentive listening. He takes the time to explain each step of the treatment to reduce patient anxiety. The practice is equipped with the latest technologies: laser, intraoral camera, digital radiography.",
    "engagement-btn": "Book appointment",
    "testimonials-title": "Patient reviews",
    "testimonials-sub": "They entrusted their smile to Dr Sadoun and share their experience.",
    "testimonial1-text": "\"Dr Sadoun is very competent and reassuring. He explained my entire implant process in detail. I highly recommend him!\"",
    "testimonial1-name": "— Karim B.",
    "testimonial2-text": "\"A modern practice, a caring team. I'm no longer afraid to go to the dentist thanks to Dr Sadoun. The results are perfect.\"",
    "testimonial2-name": "— Samia M.",
    "testimonial3-text": "\"Very warm welcome, quality care. Dr Sadoun takes the time to answer all questions. I recommend without hesitation.\"",
    "testimonial3-name": "— Leila K.",
    "testimonial4-text": "\"Excellent dental surgeon, very gentle. My children are no longer afraid of dental care. Thank you doctor!\"",
    "testimonial4-name": "— Nadia F.",
    "rdv-title": "Book an appointment online",
    "call-btn": "Call directly",
    "form-alt": "Or fill out the form below. You will be contacted shortly.",
    "form-name": "Full name",
    "form-email": "Your email",
    "form-phone": "Phone number",
    "form-message": "Message (optional)",
    "submit-btn": "Send request",
    "rdv-list-title": "Your upcoming appointments (saved locally)",
    "service-opt1": "Standard consultation",
    "service-opt2": "Scaling",
    "service-opt3": "Implantology",
    "service-opt4": "Whitening",
    "service-opt5": "Periodontics",
    "contact-title": "Practice & contacts",
    "hours-title": "Opening hours",
    "hours-desc": "Mon-Fri: 9am-6pm<br>Sat: 9am-12pm<br>Sunday: closed",
    "address-title": "Address",
    "address-desc": "Ouled Fayet<br>Algiers, 16000, Algeria",
    "contact-title2": "Contact",
    "cta-title": "Ready to take care of your smile?",
    "cta-desc": "Contact us now to schedule your consultation.",
    "cta-btn": "Call for appointment",
    "footer-name": "Dr Sadoun",
    "footer-title": "Dental Surgeon in Algiers",
    "footer-clinic": "Modern dental practice - Ouled Fayet",
    "footer-links": "Quick links",
    "footer-home": "Home",
    "footer-services": "Treatments",
    "footer-rdv": "Appointment",
    "footer-follow": "Follow us"
  },
  ar: {
    "dr-name": "د. سعدون",
    "dr-title": "جراح أسنان بالجزائر",
    "nav-home": "الرئيسية",
    "nav-services": "الخدمات",
    "nav-engagement": "العيادة",
    "nav-testimonials": "آراء المرضى",
    "nav-rdv": "موعد",
    "nav-contact": "اتصل بنا",
    "hero-badge": "رعاية حديثة بدون ألم",
    "hero-span1": "ابتسامتك",
    "hero-span2": "",
    "hero-span3": "أولوية لدينا",
    "hero-desc": "الدكتور سعدون، جراح أسنان بالجزائر (أولاد فايت)، يستقبلكم في عيادة حديثة لتقديم رعاية أسنان عالية الجودة وشخصية باستخدام أحدث التقنيات.",
    "speciality": "🦷 جراحة الأسنان وزراعة implants",
    "btn-rdv-hero": "احجز موعدًا",
    "services-title": "رعاية أسنان شاملة",
    "services-sub": "خدمات مصممة لكل مريض، من الوقاية إلى العلاجات المعقدة.",
    "service1-title": "استشارة ووقاية",
    "service1-desc": "فحص شامل، إزالة الجير، نصائح شخصية.",
    "service2-title": "علاجات تحفظية",
    "service2-desc": "علاج التسوس، ترميم الأسنان المتضررة.",
    "service3-title": "طب الأسنان التجميلي",
    "service3-desc": "تبييض، قشور خزفية، تقويم شفاف لابتسامة مشرقة.",
    "service4-title": "زراعة الأسنان",
    "service4-desc": "زراعة أسنان ثلاثية الأبعاد، إعادة بناء العظم.",
    "service5-title": "طب أسنان الأطفال",
    "service5-desc": "رعاية أسنان للأطفال في جو ممتع وخالٍ من التوتر.",
    "service6-title": "أمراض اللثة",
    "service6-desc": "علاج أمراض اللثة والوقاية منها.",
    "engagement-title": "عيادة حديثة وحنونة",
    "engagement-desc": "يحرص الدكتور سعدون على تقديم علاجات غير مؤلمة بفضل تقنيات التخدير المتقدمة والاستماع الجيد. يشرح كل خطوة من العلاج لتقليل قلق المرضى. العيادة مجهزة بأحدث التقنيات: الليزر، الكاميرا داخل الفم، الأشعة الرقمية.",
    "engagement-btn": "احجز موعدًا",
    "testimonials-title": "آراء المرضى",
    "testimonials-sub": "لقد وثقوا بابتسامتهم للدكتور سعدون ويشاركون تجربتهم.",
    "testimonial1-text": "الدكتور سعدون كفء ومطمئن جدًا. شرح لي عملية الزرع بالكامل بالتفصيل. أوصي به بشدة!",
    "testimonial1-name": "— كريم ب.",
    "testimonial2-text": "عيادة حديثة، فريق مهتم. لم أعد أخاف من الذهاب لطبيب الأسنان بفضل الدكتور سعدون. النتائج مثالية.",
    "testimonial2-name": "— سامية م.",
    "testimonial3-text": "استقبال ممتاز، رعاية جيدة. الدكتور سعدون يأخذ وقته للإجابة على جميع الأسئلة. أوصي به دون تردد.",
    "testimonial3-name": "— ليلى ك.",
    "testimonial4-text": "جراح أسنان ممتاز، لطيف جدًا. أطفالي لم يعودوا يخافون من رعاية الأسنان. شكرًا دكتور!",
    "testimonial4-name": "— نادية ف.",
    "rdv-title": "احجز موعدًا عبر الإنترنت",
    "call-btn": "اتصل مباشرة",
    "form-alt": "أو املأ النموذج أدناه. سيتم الاتصال بك قريبًا.",
    "form-name": "الاسم الكامل",
    "form-email": "بريدك الإلكتروني",
    "form-phone": "رقم الهاتف",
    "form-message": "رسالة (اختياري)",
    "submit-btn": "إرسال طلبي",
    "rdv-list-title": "مواعيدك القادمة (محفوظة محليًا)",
    "service-opt1": "استشارة عادية",
    "service-opt2": "إزالة الجير",
    "service-opt3": "زراعة الأسنان",
    "service-opt4": "تبييض",
    "service-opt5": "أمراض اللثة",
    "contact-title": "العيادة والإحداثيات",
    "hours-title": "ساعات العمل",
    "hours-desc": "الإثنين-الجمعة: 9ص-6م<br>السبت: 9ص-12م<br>الأحد: مغلق",
    "address-title": "العنوان",
    "address-desc": "أولاد فايت<br>الجزائر، 16000، الجزائر",
    "contact-title2": "اتصال",
    "cta-title": "هل أنت مستعد للعناية بابتسامتك؟",
    "cta-desc": "اتصل بنا الآن لتحديد موعد استشارتك.",
    "cta-btn": "اتصل لحجز موعد",
    "footer-name": "د. سعدون",
    "footer-title": "جراح أسنان بالجزائر",
    "footer-clinic": "عيادة أسنان حديثة - أولاد فايت",
    "footer-links": "روابط سريعة",
    "footer-home": "الرئيسية",
    "footer-services": "الخدمات",
    "footer-rdv": "موعد",
    "footer-follow": "تابعنا"
  }
};

let currentLang = localStorage.getItem('lang') || 'fr';

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('lang', lang);
  if (lang === 'ar') {
    document.body.classList.add('rtl');
  } else {
    document.body.classList.remove('rtl');
  }
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = translations[lang][key];
      } else {
        el.innerHTML = translations[lang][key];
      }
    }
  });
  document.querySelectorAll('select option').forEach(opt => {
    const key = opt.getAttribute('data-i18n');
    if (key && translations[lang][key]) opt.text = translations[lang][key];
  });
  document.querySelectorAll('.lang-btn').forEach(btn => {
    if (btn.getAttribute('data-lang') === lang) btn.classList.add('active');
    else btn.classList.remove('active');
  });
}

document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => setLanguage(btn.getAttribute('data-lang')));
});
setLanguage(currentLang);

// Dark mode
const themeToggle = document.getElementById('theme-toggle');
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark');

// Menu mobile
const toggleMenu = document.getElementById('menu-toggle');
const navLinks = document.getElementById('nav-links');
if (toggleMenu) toggleMenu.addEventListener('click', () => navLinks.classList.toggle('active'));

// Carte Leaflet
const map = L.map('map').setView([36.7380057, 2.9497374], 17);
L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>' }).addTo(map);
L.marker([36.7380057, 2.9497374]).addTo(map).bindPopup('Dr Sadoun<br>Ouled Fayet, Alger').openPopup();

// RDV localStorage
let appointments = JSON.parse(localStorage.getItem('rdv_sadoun')) || [];
function displayAppointments() {
  const list = document.getElementById('appointmentsList');
  if (list) list.innerHTML = appointments.map(apt => `<li>${apt.date} à ${apt.time} - ${apt.nom} (${apt.service})</li>`).join('');
}
const form = document.getElementById('appointmentForm');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nom = document.getElementById('nom').value;
    const email = document.getElementById('email').value;
    const tel = document.getElementById('tel').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const serviceSelect = document.getElementById('service');
    const service = serviceSelect.options[serviceSelect.selectedIndex].text;
    const message = document.getElementById('message').value;
    if (!nom || !email || !tel || !date || !time) {
      alert(currentLang === 'fr' ? "Veuillez remplir tous les champs obligatoires." : (currentLang === 'en' ? "Please fill all required fields." : "يرجى ملء جميع الحقول الإلزامية."));
      return;
    }
    const newAppointment = { nom, email, tel, date, time, service, message };
    appointments.push(newAppointment);
    localStorage.setItem('rdv_sadoun', JSON.stringify(appointments));
    displayAppointments();
    alert(currentLang === 'fr' ? "Demande envoyée ! Le docteur vous recontactera rapidement." : (currentLang === 'en' ? "Request sent! The doctor will contact you shortly." : "تم إرسال الطلب! سيتصل بك الطبيب قريبًا."));
    form.reset();
  });
}
displayAppointments();

// Animations scroll
const faders = document.querySelectorAll('.fade-up');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });
faders.forEach(el => observer.observe(el));